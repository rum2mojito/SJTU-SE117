#include <FL/Fl.h>
#include <FL/Fl_Box.H>
#include <FL/Fl_Window.H>
#include "Point.h"
#include "GUI.h"
#include "Graph.h"
#include "Window.h"
#include "Simple_window.h"
#include "std_lib_facilities.h"
#include <iostream>



int main()
{

    Simple_window win1(Point(100 , 100),600,400,"two line");

    Circle c1(Point(120, 150), 60);
	c1.set_color(Color::blue);
	win1.attach(c1);

	Circle c2(Point(250, 150), 60);
	c2.set_color(Color::black);
	win1.attach(c2);

	Circle c3(Point(380, 150), 60);
	c3.set_color(Color::red);
	win1.attach(c3);

	Circle c4(Point(185, 210), 60);
	c4.set_color(Color::yellow);
	win1.attach(c4);

	Circle c5(Point(315, 210), 60);
	c5.set_color(Color::green);
	win1.attach(c5);

	win1.wait_for_button();

    return 0;
}